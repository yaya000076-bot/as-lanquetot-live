// Collez ici les 4 valeurs de votre projet Firebase (voir GUIDE.md, étape 3).
// Remplacez uniquement le texte entre guillemets, sans toucher au reste.
export const FIREBASE_CONFIG = {
  apiKey: "COLLEZ_ICI",
  authDomain: "COLLEZ_ICI",
  projectId: "COLLEZ_ICI",
  appId: "COLLEZ_ICI"
};
