# Mise en ligne – A.S. Lanquetot (matchs en direct)

Prévoyez 30 minutes, **sur un ordinateur**. Seul le fichier `firebase-config.js` est à modifier.

## 1. Base de données (Firebase, gratuit)
1. https://console.firebase.google.com → **Ajouter un projet** (`asl-matchs`, Analytics désactivé).
2. **Firestore Database → Créer une base de données** → région européenne, mode **production**.
3. Onglet **Règles** : collez le contenu de `firestore.rules` **en remplaçant `REMPLACEZ@VOTRE-EMAIL.FR` par votre e-mail**, puis **Publier**.

## 2. Votre accès dirigeant
**Authentication → Commencer → E-mail/Mot de passe → Activer**, puis **Utilisateurs → Ajouter un utilisateur** avec **le même e-mail** que dans les règles et un mot de passe solide.

## 3. Relier le site
**Paramètres du projet → Vos applications → icône Web `</>`** → Enregistrer. Copiez `apiKey`, `authDomain`, `projectId`, `appId` dans `firebase-config.js` (à la place des `COLLEZ_ICI`). Enregistrez.

## 4. Publier sur Netlify (gratuit)
1. https://app.netlify.com/drop → glissez **tout le dossier** `site-asl` (ou le fichier `site-asl.zip`).
2. Créez un compte Netlify pour garder le site. Changez l’adresse dans **Site configuration → Change site name**.
3. Retour dans Firebase : **Authentication → Paramètres → Domaines autorisés** → ajoutez votre adresse `xxx.netlify.app`.

## 5. Premier essai
Ouvrez l’adresse **depuis Netlify** (le site ne fonctionne pas en ouvrant le fichier directement sur l’ordinateur). **Espace dirigeant** en bas → connexion → onglet *Club* : nom du club et catégories ; puis *Effectif* ; puis *Match*. Testez un but avec un autre téléphone.

## Mises à jour futures
Si je vous renvoie un nouveau `index.html`, remplacez seulement ce fichier : votre `firebase-config.js` n’est pas touché. Redéposez le dossier sur Netlify (Deploys → glisser le dossier).

## Autre dirigeant
Créez son e-mail dans Authentication, puis dans les règles : `request.auth.token.email in ["vous@exemple.fr", "autre@exemple.fr"]`.
